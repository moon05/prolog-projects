Abdullah Al Mamun
CSC 173
Prolog Week 2
TA: Kevin Gerami

The folder contains 4 files.
1. prolog2.pl
2. Mission.txt
3. Readme.txt (this file)
4. sample_interaction.txt

In general it was very hard for me to wrap my head around the fact
that there are Variables in Prolog but I can't "really" use them
as I would use variables in other languages. For every rule (I think
that's what functions are called in Prolog), I had a hard time with
this.

When starting with the Tree part, I had a hard time even to get
started with coding as I coldn'
It figure out how can I write anything
without writing a Tree data stucture. As in, how would I call the
".leftChild" or ".rightChild" or ".parent". But then someone explained
me that, it's not really necessary as it's all about recurions and the
whole tree is kind of given as a "input".

Same thing happened with the List part. I was clueless about calling
".next" or ".prev".

The hardest time I had in Tree part was increment_tree. I had to think a
LOT on how to keep adding the 1 and then how would it worj on the nodes
recursively.

Extra credit:
--------------
I have implemented list_reverse which reverses a list.
I tired to do list_prefix which would basically do the opposit of
list_suffix but it didn't work out.
I implemented is_element which basically does the same thing as
lis_element and also if you give it "X" then it lists all the elements.
I implemented del_duplicate which deletes duplicates in a list